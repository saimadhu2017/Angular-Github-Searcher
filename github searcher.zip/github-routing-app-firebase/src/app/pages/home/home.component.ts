import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';
import { GithubService } from 'src/app/services/github.service';
import { HeaderComponent } from '../../layout/header/header.component';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  user: any = null;//this will be coming from request
  userName!: string;//this will be coming from form
  Error: any = null;

  constructor(private githubService: GithubService, private ref: ChangeDetectorRef, private auth: AuthService,private router:Router) { }

  ngOnInit(): void {
    if (sessionStorage.getItem('user')) {
      let tempCheck: boolean;
      this.auth.checkUserThere(<string>sessionStorage.getItem('user')).subscribe(
        (res) => {
          tempCheck = res;
          if (!tempCheck) {
            this.handelSignOut();
          }
        },
        (err) => {
          this.handelSignOut();
        }
      )
    }
  }

  handelFind() {
    this.githubService.getUserDetailes(this.userName).subscribe(
      (user: any) => {
        this.user = user;
        this.Error = null;
        // this.ref.detectChanges();//it detect changes and refill the values
      },
      (err) => {
        this.user = null;
        this.Error = "User Not Found";
        // this.ref.detectChanges();//because user will searching after error so we written
      }
    );
  }

  handelSignOut() {
    this.auth.signOut();
    sessionStorage.removeItem('user');
    this.router.navigate(['/signin']);
  }

}
