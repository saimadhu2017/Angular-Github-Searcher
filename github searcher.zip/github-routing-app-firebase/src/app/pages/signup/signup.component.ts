import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../services/auth.service';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  errMessage:string="";

  constructor(private auth:AuthService,private toastr: ToastrService,private router:Router) { }

  ngOnInit(): void {
  }

  signUp(email:string,password:string){
    this.auth.signUp(email,password).subscribe(
      (result:any)=>{this.errMessage=result; this.toastr.success(this.errMessage); this.router.navigate(['/signin'])},
      (err:any)=>{this.errMessage=err;this.toastr.error(this.errMessage);}
    );
  }

}
