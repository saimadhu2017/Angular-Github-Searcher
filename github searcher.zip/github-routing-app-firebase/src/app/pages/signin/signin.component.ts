import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { AuthService } from '../../services/auth.service';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';
import { HeaderComponent } from 'src/app/layout/header/header.component';

@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.css']
})
export class SigninComponent implements OnInit {
  errMessage: string = "";
  @ViewChild('email') email!:ElementRef;

  constructor(private auth: AuthService, private toastr: ToastrService, private router: Router) { }

  ngOnInit(): void {
  }

  signIn(email: string, password: string) {
    this.auth.signin(email, password).subscribe(
      (result: any) => {
        this.errMessage = result;
        sessionStorage.setItem('user',this.getEmail());
        this.toastr.success(this.getEmail()+" Successfully Logged in");
        this.router.navigate(['/']);
      },
      (err: any) => {
        this.errMessage = err;
        this.toastr.error(this.errMessage);
      }
    );
  }

  getEmail(){
    return(this.email.nativeElement.value);
  }

}
