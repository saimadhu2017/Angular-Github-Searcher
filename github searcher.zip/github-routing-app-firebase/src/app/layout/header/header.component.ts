import { Component, DoCheck, OnInit, } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit,DoCheck{

  email: any = null;

  constructor(private auth: AuthService, private toastr: ToastrService, private router: Router) {
    
  }
  ngDoCheck(): void {
    this.email=sessionStorage.getItem('user');
  }

  ngOnInit(): void {
    if(sessionStorage.getItem('user')){
      let tempCheck:boolean;
      this.auth.checkUserThere(<string>sessionStorage.getItem('user')).subscribe(
        (res)=>{
          tempCheck=res;
          if(!tempCheck){this.handelSignOut();}
        },
        (err)=>{
          this.handelSignOut();
        }
      )
    }
  }

  handelSignOut() {
    this.auth.signOut();
    this.email = null;
    sessionStorage.removeItem('user');
    this.router.navigate(['/signin']);
    this.toastr.error("Your are logged Out");
  }

}
