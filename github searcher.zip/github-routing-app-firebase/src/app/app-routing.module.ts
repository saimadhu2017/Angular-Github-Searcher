import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { HomeComponent } from './pages/home/home.component';
import { PagenotfoundComponent } from './pages/pagenotfound/pagenotfound.component';
import { SigninComponent } from './pages/signin/signin.component';
import { SignupComponent } from './pages/signup/signup.component';
import { LogginGaurdService } from './router-gaurds-service/isLoggedInGaurd';
import { NotLogginGaurdService } from './router-gaurds-service/notLoggedInGaurd';

const routes: Routes = [
  {path:'',component:HomeComponent, canActivate:[LogginGaurdService]},
  {path:'signin',component:SigninComponent,canActivate:[NotLogginGaurdService]},
  {path:'signup',component:SignupComponent,canActivate:[NotLogginGaurdService]},
  {path:'**',component:PagenotfoundComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
