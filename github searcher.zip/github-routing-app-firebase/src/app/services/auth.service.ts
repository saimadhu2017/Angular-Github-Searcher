import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private isLoggedin: boolean = false;
  private userEmail: any = null;

  constructor(private http: HttpClient) { }

  signUp(email: string, password: string): Observable<any> {
    const options = new HttpHeaders({ 'Content-Type': 'application/json' });
    return (
      this.http.post<any>('http://localhost:1000/signup', { "email": email, "password": password }, { headers: options }).pipe(
        map((response:any)=>{
          return(response.message);
        }),
        catchError(this.handelError)
      )
    );
  }

  signin(email: string, password: string): Observable<any> {
    return (
      this.http.get(`http://localhost:1000/signin/${email}/${password}`).pipe(
        map((response: any) => {
          if (response.message === "valid user") {
            this.isLoggedin = true;
            this.userEmail = response.result.email;
          } else {
            this.isLoggedin = false;
            this.userEmail = null;
          }
          return (this.isLoggedin);
        }),
        catchError(this.handelError)
      )
    );
  }

  checkUserThere(email: string):Observable<any>{
    return(
      this.http.get(`http://localhost:1000/user/${email}`).pipe(
        map((response:any)=>{
          if (response.message === "Valid User"){
            return(true);
          }else{
            return(false);
          }
        }),
        catchError(this.handelError)
      )
    );
  }

  isLoggedIn(){
    if(sessionStorage.getItem('user')){
      this.isLoggedin=true;
      return(this.isLoggedin);
    }else{
      return(this.isLoggedin);
    }
    
  }

  signOut() {
    this.isLoggedin = false;
    this.userEmail = "";
  }

  private handelError(err: HttpErrorResponse): Observable<any> {
    let errMsg = '';
    if (err.error instanceof Error) {
      errMsg = err.error.message
    } else {
      errMsg = err.error.message ?? "Please try again later There is a problem with server";
    }
    return (throwError(errMsg));
  }

}
