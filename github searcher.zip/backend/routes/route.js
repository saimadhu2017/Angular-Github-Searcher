const express = require('express');
const router = express.Router();
const { signin, signup, user } = require('../controllers/controller');

router.get('/signin/:email/:password', signin);

router.post('/signup', signup);

router.get('/user/:email',user);

module.exports = router;