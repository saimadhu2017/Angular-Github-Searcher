const express = require('express');
const app = express();
const mongoose = require('mongoose');
const router = require('./routes/route');
var bodyParser = require('body-parser');
var cors = require('cors');

app.use(cors());
app.use(bodyParser.json());
app.use('/', router);

mongoose.connect("mongodb://localhost:27017/Users", {
    useNewUrlParser: true,
}).then(
    () => { console.log("DB IS UP AND RUNNING"); }
).catch(
    () => { console.log("DB IS NOT RUNNING"); }
);

app.listen(1000, () => {
    console.log("SERVER IS UP AND RUNNIGN AT PORT 1000");
});