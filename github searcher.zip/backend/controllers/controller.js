const userModel = require('../models/model');

exports.signin = async (req, res) => {
    try {
        const result = await userModel.find({
            $and: [
                { email: req.params.email },
                { password: req.params.password }
            ]
        });
        if (result.length == 1) {
            let { _id, email } = result[0];
            return (
                res.status(200).json({
                    status: "success",
                    message: "valid user",
                    result: {
                        id: _id,
                        email: email
                    }
                })
            );
        } else {
            return (
                res.status(400).json({
                    status: "fail",
                    message: "invalid user"
                })
            );
        }
    } catch (error) {
        return (
            res.status(400).json({
                status: "fail",
                message: "Error"
            })
        );
    }
}

exports.signup = async (req, res) => {
    try {
        await userModel.create(req.body);
        return (
            res.status(200).json({
                status: "success",
                message: "Great Signed up!"
            })
        );
    } catch (error) {
        return (
            res.status(400).json({
                status: "fail",
                message: "Sorry Not Signed up!"
            })
        );
    }
}

exports.user = async (req,res) => {
    try {
        const result=await userModel.find({email: req.params.email});
        if(result.length==1){
            return (
                res.status(200).json({
                    status: "success",
                    message: "Valid User"
                })
            );
        }else{
            return (
                res.status(400).json({
                    status: "fail",
                    message: "Invalid User"
                })
            );
        }
    } catch (error) {
        return (
            res.status(400).json({
                status: "fail",
                message: "Invalid User"
            })
        );
    }
}